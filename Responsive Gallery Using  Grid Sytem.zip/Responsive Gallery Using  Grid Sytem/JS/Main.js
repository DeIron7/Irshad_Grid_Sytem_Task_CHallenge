$(document).ready(function () {
  var grid__items = document.querySelectorAll(".grid .grid__item");
  
  grid__items.forEach((element) => {
    element.addEventListener("mouseover", function () {
      Unactive__Grid__Items();
      element.classList.add("active__grid__item");
      element.classList.remove("unactive__grid__item");
    });
  });

  grid__items.forEach((element) => {
    element.addEventListener("mouseleave", function () {
      UnactiveActive__Grid__Items();
    });
  });

  function Unactive__Grid__Items() {
    for (var i = 0; i < grid__items.length; i++) {
      grid__items[i].classList.add("unactive__grid__item");
      grid__items[i].classList.remove("active_unactive_grids");
    }
  }
  function UnactiveActive__Grid__Items() {
    for (var i = 0; i < grid__items.length; i++) {
      grid__items[i].classList.add("active_unactive_grids");
      grid__items[i].classList.remove("unactive__grid__item");
      grid__items[i].classList.remove("active__grid__item");
    }
  }
});
